package cs65.dartmouth.get_swole;

// Place to store all Global variables and lists
public class Globals {

	public static final String TAG = "GET_SWOLE";
	
	public static final String ID_TAG = "Id";
	public static final String NAME_TAG = "WorkoutName";
}
