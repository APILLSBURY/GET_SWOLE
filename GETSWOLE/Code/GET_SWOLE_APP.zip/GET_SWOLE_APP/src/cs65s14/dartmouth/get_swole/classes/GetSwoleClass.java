package cs65s14.dartmouth.get_swole.classes;

public class GetSwoleClass {

	protected long id;
	protected String name;
	
	public long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setId(long i) {
		id = i;
	}
	
	public void setName(String n) {
		name = n;
	}
	

}
