/** Automatically generated file. DO NOT MODIFY */
package cs65s14.dartmouth.get_swole;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}