package cs65.dartmouth.get_swole.gcm;

public class Response {
	int mHttpStatus = -1;
	String mMessage = "";
}
