package cs65.dartmouth.get_swole.data;

import java.io.UnsupportedEncodingException;
import android.util.Base64;
import android.util.Log;
import com.google.appengine.api.datastore.Blob;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Text;


public class EntityConverter {

	public static ProfileObject fromEntitytoProfile(Entity entity) {
		
		ProfileObject profile = new ProfileObject();
		
		profile.regId = (String) entity.getProperty("regId");
		
		profile.profilePicture = (String) ((Text) entity.getProperty("profilePicture")).getValue();
		
		profile.firstName = (String) entity.getProperty("firstName");
		profile.lastName = (String) entity.getProperty("lastName");
		profile.hometown = (String) entity.getProperty("hometown");
		profile.sport = (String) entity.getProperty("sport");
	
		return profile;
	}
	
	public static Entity toEntityfromProfile(ProfileObject entry, String kind, Key parentKey) {
		
		Entity entity = new Entity(kind, entry.regId, parentKey);
		
		entity.setProperty("regId", entry.regId);
		
		entity.setProperty("profilePicture", new Text(entry.profilePicture));

		entity.setProperty("firstName", entry.firstName);
		entity.setProperty("lastName", entry.lastName);
		entity.setProperty("hometown", entry.hometown);
		entity.setProperty("sport", entry.sport);
		
		return entity;
		
	}
	
//	String photoString = Base64.encodeToString(pictureArray, Base64.DEFAULT);
//	
//	Log.d("CJP", "Byte Array string\n" + photoString);
//	
//	pictureArray = Base64.decode(photoString, Base64.DEFAULT);
	
}
